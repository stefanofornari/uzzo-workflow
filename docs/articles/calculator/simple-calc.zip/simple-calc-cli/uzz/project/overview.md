# Project Overview

## Identity

- **Name**: simple-calc
- **Version**: 0.0.0-SNAPSHOT
- **Summary**: [One paragraph describing what the project is, who it serves, and the problem it solves.]

## Team & Roles

| Person | Role | Responsibilities |
|--------|------|------------------|
| [NAME] | [ROLE] | [RESPONSIBILITIES] |

## Timeline

- **Start**: [YYYY-MM-DD]
- **Milestones**:
  - [MILESTONE] — [YYYY-MM-DD]

## Repositories

- [REPOSITORY NAME]([URL]) — [PURPOSE]

## Architecture

The desktop user interface is built with JavaFX 23. The application uses Java 21
and Maven and targets Windows, macOS, and Linux. Installable platform packages
include the JavaFX libraries and require Java 21 to be installed separately.
Further component boundaries and data flow have not yet been established.

### Keywords
- project
- overview
- team
- timeline
- repositories
- architecture
