# Development Framework

## Purpose

[How this project is built, tested, and run.]

## Technology Stack

- **Language / Runtime**: Java 21
- **Frameworks / Libraries**: JavaFX 23
- **Build Tool**: Maven
- **Test Tools**: JUnit 5.10.2

## Development Workflow

- [e.g. TDD: write a failing test, make it pass, refactor]
- [Branching, review, or release convention]
- [Additional workflow rule]

## Build and Execution

- **Build**: `mvn compile`
- **Test**: `mvn test`
- **Run**: `mvn javafx:run`

### Keywords
- development-framework
- toolchain
- build
- testing
- workflow
