# Implementation Notes

- History stores only successful expressions in memory for the current application session, newest first.
- Keep no more than 20 expressions; history is navigated with Up/Down and is not shown as a separate list.
- Failed calculations are not recorded, and there is no clear-history action.
- Up/Down navigation, draft restoration, and result clearing are consolidated in US-000004.
- If the visible expression is already the newest successful expression, the first Up skips it and recalls the preceding entry.
