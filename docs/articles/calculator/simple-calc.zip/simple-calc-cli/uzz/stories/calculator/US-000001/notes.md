# Implementation Notes

- The input model uses a JavaFX string property so keyboard edits in the expression field and keypad presses share the same current-expression state.
- The Maven build uses JavaFX 23.0.2 and launches the desktop application with `mvn javafx:run`.
- The input model is covered by JUnit tests; rendering and visual styling require a desktop display.
