# Implementation Notes

- The first Up press saves the current expression as a draft before entering history navigation.
- Down walks toward newer expressions and restores the saved draft after the newest entry.
- Up at the oldest entry remains at that boundary; navigating history clears the displayed result without evaluating the recalled expression.
