# Implementation Notes

- Expected arithmetic and syntax failures are represented as an explicit `Error` result in the UI.
- Error results use a distinct visual state; successful evaluation clears that state.
- The display layer handles only arithmetic and invalid-expression exceptions, leaving unexpected failures visible to developers.
