# Implementation Notes

- The expression evaluator uses recursive descent to enforce conventional operator precedence and parentheses.
- BigDecimal arithmetic avoids binary floating-point representation errors; non-terminating division uses MathContext.DECIMAL128.
- The result display removes insignificant trailing zeros while leaving the entered expression unchanged.
