# Project Name: simple-calc
**Version:** 0.0.0-SNAPSHOT

## Overall Description

Build a simple calculator desktop application that runs on Windows, macOS, and
Linux. Users can enter expressions with the keyboard or an on-screen keypad,
see the current expression, and press Enter to calculate it. The interface
should have a clean, modern look.

The calculator supports addition, subtraction, multiplication, and division;
decimal numbers; unary minus; conventional operator precedence; and
parentheses for grouping. After a successful calculation, show the result and
keep the expression visible. For division by zero, unbalanced parentheses, or
other invalid expressions, show a simple error.

The application keeps a session-only history of the 20 most recent successful
expressions. It does not show a separate history list or saved results. Pressing
Up recalls the newest expression and then older ones. If the current expression
is already the newest successful calculation, Up moves to the preceding older
expression instead. Pressing Down moves toward newer expressions and, past the
newest, restores the expression that was being edited before history navigation
began. Browsing history clears the displayed result and does not evaluate the
recalled expression. There is no clear-history action.

Provide an installable package for Windows, macOS, and Linux. Users install,
launch, and uninstall the application through the operating system's normal
mechanisms. The application requires Java 21 to be installed separately; it
does not bundle a Java runtime. Each package includes the JavaFX libraries
needed by the interface.

## In-Scope Capabilities
* **Calculator**:
  - [ ] Run as a desktop application on Windows, macOS, and Linux.
  - [ ] Provide keyboard entry and an on-screen keypad for expressions.
  - [ ] Show the current expression.
  - [ ] Evaluate expressions on Enter, showing the result while keeping the expression visible.
  - [ ] Support addition, subtraction, multiplication, division, decimal numbers, unary minus, conventional precedence, and parentheses.
  - [ ] Show a simple error for division by zero, unbalanced parentheses, and other invalid expressions.
  - [ ] Present a clean, modern interface.
* **Calculation History**:
  - [ ] Keep the 20 most recent successful expressions for the current app session.
  - [ ] Pressing Up recalls the newest earlier expression; if the current expression is the newest successful calculation, it recalls the preceding older expression.
  - [ ] Pressing Down moves toward newer expressions; pressing Down past the newest restores the pre-navigation expression.
  - [ ] Keep the oldest expression selected when Up is pressed at the history boundary.
  - [ ] Clear the displayed result while browsing; do not evaluate recalled expressions until Enter is pressed.
  - [ ] Do not show a separate history list or provide a clear-history action.
* **Installation & Launch**:
  - [ ] Provide an installable package for Windows, macOS, and Linux.
  - [ ] Install and uninstall through the operating system's normal mechanisms, and provide an application-launcher entry.
  - [ ] Require Java 21 to be installed separately; do not bundle the runtime.
  - [ ] Include JavaFX libraries in each platform package.

## Out-of-Scope / Future Enhancements
* Scientific, graphing, memory, or variable features; they are not part of the requested basic calculator.
* Persisting calculation history across application restarts.
* Displaying a separate list of historical expressions or results.
* In-app automatic updates and distribution through app stores or package repositories.

## Technical Context & Infrastructure
* **Development Toolchain**: Java 21 + Maven
* **Target Systems/Platforms**: Windows, macOS, and Linux desktop
* **UI Framework**: JavaFX 23.
* **Runtime Requirement**: Java 21 installed separately on the target system; JavaFX libraries are included in each application package.
* **Project Reference Docs**:
  - Coding Standard: `uzz/project/coding_standard.md`
  - Development Framework: `uzz/project/development_framework.md`

### Keywords
- calculator
- desktop
- arithmetic
- expressions
- cross-platform
- scope
