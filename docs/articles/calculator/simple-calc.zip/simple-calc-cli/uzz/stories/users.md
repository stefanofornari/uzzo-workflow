# Users

Actors referenced by the `AS A [role]` clause of user stories. This list is
authoritative: stories must not invent roles that are not listed here. Add a
role only when the project genuinely has it.

- **User**: A person who installs and launches the calculator, enters expressions, calculates results, and reviews recent calculations.

### Keywords
- users
- actors
- personas
- roles
