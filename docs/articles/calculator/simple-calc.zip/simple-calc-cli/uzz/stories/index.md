# Stories Index

> One `##` section per domain. Inside each section, a table with
> `id | title | status`, where status is one of `TODO`, `WIP`, `DONE`, `BLOCKED`, `CLOSED`.
> New stories default to `TODO`; preserve existing statuses.

## calculator

| id | title | status |
|----|-------|--------|
| calculator/US-000001 | Enter and View Calculator Expressions | DONE |
| calculator/US-000002 | Evaluate Arithmetic Expressions | DONE |
| calculator/US-000003 | Receive Errors for Invalid Calculations | DONE |
| calculator/US-000004 | Browse Recent Expressions with Arrow Keys | DONE |
| calculator/US-000005 | Merged into calculator/US-000004 | CLOSED |

## setup

| id | title | status |
|----|-------|--------|
| setup/US-000006 | Install and Launch on Windows | TODO |
| setup/US-000007 | Install and Launch on macOS | TODO |
| setup/US-000008 | Install and Launch on Linux | TODO |

### Keywords
- stories
- index
- backlog
