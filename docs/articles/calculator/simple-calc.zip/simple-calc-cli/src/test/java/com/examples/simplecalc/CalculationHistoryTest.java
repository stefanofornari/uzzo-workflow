package com.examples.simplecalc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import java.util.List;
import org.junit.jupiter.api.Test;

class CalculationHistoryTest {

    @Test
    void recordsExpressionForSuccessfulCalculation() {
        CalculationHistory history = new CalculationHistory();

        history.record("2 + 3", new CalculationDisplay.Display("5", false));

        assertEquals(List.of("2 + 3"), history.expressions());
    }

    @Test
    void upRecallsMostRecentExpression() {
        CalculationHistory history = new CalculationHistory();
        history.record("2 + 3", new CalculationDisplay.Display("5", false));

        assertEquals("2 + 3", history.navigateOlder("draft").orElseThrow());
    }

    @Test
    void upMovesToPreviousEntryWhenCurrentExpressionIsAlreadyNewest() {
        CalculationHistory history = new CalculationHistory();
        history.record("1 + 1", new CalculationDisplay.Display("2", false));
        history.record("2 + 3", new CalculationDisplay.Display("5", false));

        assertEquals("1 + 1", history.navigateOlder("2 + 3").orElseThrow());
        assertEquals("2 + 3", history.navigateNewer().orElseThrow());
        assertEquals("2 + 3", history.navigateNewer().orElseThrow());
    }

    @Test
    void doesNotRecordFailedCalculation() {
        CalculationHistory history = new CalculationHistory();

        history.record("5 / 0", new CalculationDisplay.Display("Error", true));

        assertTrue(history.expressions().isEmpty());
    }

    @Test
    void retainsOnlyTheTwentyMostRecentEntries() {
        CalculationHistory history = new CalculationHistory();
        for (int calculation = 1; calculation <= 21; calculation++) {
            String value = Integer.toString(calculation);
            history.record(value, new CalculationDisplay.Display(value, false));
        }

        assertEquals(20, history.expressions().size());
        assertEquals("21", history.expressions().get(0));
        assertEquals("2", history.expressions().get(19));
    }

    @Test
    void newSessionStartsWithEmptyHistory() {
        CalculationHistory previousSession = new CalculationHistory();
        previousSession.record("2 + 3", new CalculationDisplay.Display("5", false));

        CalculationHistory newSession = new CalculationHistory();

        assertTrue(newSession.expressions().isEmpty());
    }

    @Test
    void upNavigatesFromNewestToOlderAndStopsAtOldest() {
        CalculationHistory history = new CalculationHistory();
        history.record("1 + 1", new CalculationDisplay.Display("2", false));
        history.record("2 + 3", new CalculationDisplay.Display("5", false));

        assertEquals("2 + 3", history.navigateOlder("draft").orElseThrow());
        assertEquals("1 + 1", history.navigateOlder("2 + 3").orElseThrow());
        assertEquals("1 + 1", history.navigateOlder("1 + 1").orElseThrow());
    }

    @Test
    void downNavigatesNewerThenRestoresDraft() {
        CalculationHistory history = new CalculationHistory();
        history.record("1 + 1", new CalculationDisplay.Display("2", false));
        history.record("2 + 3", new CalculationDisplay.Display("5", false));
        history.navigateOlder("6 * 7");
        history.navigateOlder("2 + 3");

        assertEquals("2 + 3", history.navigateNewer().orElseThrow());
        assertEquals("6 * 7", history.navigateNewer().orElseThrow());
        assertTrue(history.navigateNewer().isEmpty());
    }

    @Test
    void downDoesNothingWhenNotBrowsingHistory() {
        CalculationHistory history = new CalculationHistory();

        assertTrue(history.navigateNewer().isEmpty());
    }
}
