package com.examples.simplecalc;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.Test;

class CalculationDisplayTest {

    @Test
    void showsErrorInsteadOfResultForDivisionByZero() {
        CalculationDisplay.Display display = new CalculationDisplay().evaluate("5 / 0");

        assertEquals("Error", display.text());
        assertTrue(display.isError());
    }

    @Test
    void showsErrorInsteadOfResultForUnbalancedParentheses() {
        CalculationDisplay.Display display = new CalculationDisplay().evaluate("1 + (2 * 3");

        assertEquals("Error", display.text());
        assertTrue(display.isError());
    }

    @Test
    void showsErrorInsteadOfResultForOtherInvalidExpressions() {
        CalculationDisplay.Display display = new CalculationDisplay().evaluate("2 + * 3");

        assertEquals("Error", display.text());
        assertTrue(display.isError());
    }

    @Test
    void successfulCalculationClearsErrorState() {
        CalculationDisplay.Display display = new CalculationDisplay().evaluate("2 + 3");

        assertEquals("5", display.text());
        assertFalse(display.isError());
    }
}
