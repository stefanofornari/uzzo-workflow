package com.examples.simplecalc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.math.BigDecimal;
import org.junit.jupiter.api.Test;

class ExpressionEvaluatorTest {

    @Test
    void evaluatesOperatorsWithPrecedenceAndParentheses() {
        ExpressionEvaluator evaluator = new ExpressionEvaluator();

        assertEquals(new BigDecimal("2"), evaluator.evaluate("10 - 8 / 2 * (3 - 1)"));
    }

    @Test
    void evaluatesDecimalNumbersAndUnaryNegative() {
        ExpressionEvaluator evaluator = new ExpressionEvaluator();

        assertEquals(new BigDecimal("10.5"), evaluator.evaluate("(-2.5 + 6) * (4 - 1)"));
    }

    @Test
    void divisionCanProduceDecimalResults() {
        ExpressionEvaluator evaluator = new ExpressionEvaluator();

        assertEquals(new BigDecimal("0.125"), evaluator.evaluate("1 / 8"));
    }
}
