package com.examples.simplecalc;

import static org.junit.jupiter.api.Assertions.assertEquals;

import org.junit.jupiter.api.Test;

class CalculatorInputTest {

    @Test
    void keyboardTextUpdatesCurrentExpression() {
        CalculatorInput input = new CalculatorInput();

        input.setExpression("12 + (3");

        assertEquals("12 + (3", input.getExpression());
    }

    @Test
    void keypadKeysAppendToCurrentExpression() {
        CalculatorInput input = new CalculatorInput();

        input.append("1");
        input.append("2");
        input.append(" + ");
        input.append("(");
        input.append("3");

        assertEquals("12 + (3", input.getExpression());
    }
}
