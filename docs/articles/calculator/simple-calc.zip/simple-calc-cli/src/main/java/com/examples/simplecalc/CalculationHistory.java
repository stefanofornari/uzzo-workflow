package com.examples.simplecalc;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public final class CalculationHistory {

    private static final int MAX_EXPRESSIONS = 20;

    private final List<String> expressions = new ArrayList<>();
    private int navigationIndex = -1;
    private String draftExpression;

    public List<String> expressions() {
        return List.copyOf(expressions);
    }

    public void record(String expression, CalculationDisplay.Display display) {
        if (display.isError()) {
            return;
        }

        expressions.add(0, expression);
        if (expressions.size() > MAX_EXPRESSIONS) {
            expressions.remove(expressions.size() - 1);
        }
        navigationIndex = -1;
        draftExpression = null;
    }

    public Optional<String> navigateOlder(String currentExpression) {
        if (expressions.isEmpty()) {
            return Optional.empty();
        }

        if (navigationIndex == -1) {
            draftExpression = currentExpression;
            navigationIndex = expressions.size() > 1 && expressions.get(0).equals(currentExpression) ? 1 : 0;
        } else if (navigationIndex < expressions.size() - 1) {
            navigationIndex++;
        }
        return Optional.of(expressions.get(navigationIndex));
    }

    public Optional<String> navigateNewer() {
        if (navigationIndex == -1) {
            return Optional.empty();
        }

        if (navigationIndex == 0) {
            navigationIndex = -1;
            String expression = draftExpression;
            draftExpression = null;
            return Optional.of(expression);
        }

        navigationIndex--;
        return Optional.of(expressions.get(navigationIndex));
    }
}
