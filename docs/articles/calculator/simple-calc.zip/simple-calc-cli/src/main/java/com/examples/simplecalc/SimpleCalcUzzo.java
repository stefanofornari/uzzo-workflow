/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.examples.simplecalc;

import java.util.List;
import javafx.application.Application;
import javafx.css.PseudoClass;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.RowConstraints;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class SimpleCalcUzzo extends Application {

    private static final PseudoClass ERROR_STATE = PseudoClass.getPseudoClass("error");

    private static final List<List<String>> KEYPAD_ROWS = List.of(
            List.of("7", "8", "9", "/"),
            List.of("4", "5", "6", "*"),
            List.of("1", "2", "3", "-"),
            List.of("(", "0", ")", "+"),
            List.of("."));

    @Override
    public void start(Stage stage) {
        CalculatorInput input = new CalculatorInput();
        TextField expressionField = new TextField();
        expressionField.setId("expression-field");
        expressionField.setPromptText("Enter an expression");
        expressionField.setAlignment(Pos.CENTER_RIGHT);
        expressionField.textProperty().bindBidirectional(input.expressionProperty());
        Label result = new Label();
        result.setId("result-display");

        CalculationHistory history = new CalculationHistory();
        CalculationDisplay calculationDisplay = new CalculationDisplay();
        expressionField.setOnAction(event -> {
            CalculationDisplay.Display display = calculationDisplay.evaluate(input.getExpression());
            result.setText(display.text());
            result.pseudoClassStateChanged(ERROR_STATE, display.isError());
            history.record(input.getExpression(), display);
        });

        Label title = new Label("CALCULATOR");
        title.getStyleClass().add("calculator-title");

        GridPane keypad = createKeypad(input);
        VBox layout = new VBox(18, title, expressionField, result, keypad);
        layout.setAlignment(Pos.TOP_CENTER);
        layout.setPadding(new Insets(28));
        layout.getStyleClass().add("calculator-root");

        Scene scene = new Scene(layout);
        scene.getStylesheets().add(getClass().getResource("calculator.css").toExternalForm());
        scene.addEventFilter(KeyEvent.KEY_PRESSED, event -> {
            if (event.getCode() == KeyCode.UP) {
                history.navigateOlder(input.getExpression()).ifPresent(expression -> {
                    showHistoryExpression(input, result, expression);
                    event.consume();
                });
            } else if (event.getCode() == KeyCode.DOWN) {
                history.navigateNewer().ifPresent(expression -> {
                    showHistoryExpression(input, result, expression);
                    event.consume();
                });
            }
        });
        stage.setTitle("Simple Calculator");
        stage.setMinWidth(360);
        stage.setMinHeight(480);
        stage.setScene(scene);
        stage.show();
        expressionField.requestFocus();
    }

    private GridPane createKeypad(CalculatorInput input) {
        GridPane keypad = new GridPane();
        keypad.setHgap(10);
        keypad.setVgap(10);
        keypad.setAlignment(Pos.CENTER);

        for (int row = 0; row < KEYPAD_ROWS.size(); row++) {
            List<String> keys = KEYPAD_ROWS.get(row);
            for (int column = 0; column < keys.size(); column++) {
                String key = keys.get(column);
                Button button = new Button(key);
                button.getStyleClass().add("keypad-button");
                if ("/".equals(key) || "*".equals(key) || "-".equals(key) || "+".equals(key)) {
                    button.getStyleClass().add("operator-button");
                }

                button.setMaxSize(Double.MAX_VALUE, Double.MAX_VALUE);
                button.setOnAction(event -> input.append(key));
                keypad.add(button, column, row);
            }
        }

        for (int column = 0; column < 4; column++) {
            ColumnConstraints constraints = new ColumnConstraints();
            constraints.setPercentWidth(25);
            constraints.setFillWidth(true);
            keypad.getColumnConstraints().add(constraints);
        }
        for (int row = 0; row < KEYPAD_ROWS.size(); row++) {
            RowConstraints constraints = new RowConstraints();
            constraints.setMinHeight(54);
            constraints.setPercentHeight(20);
            keypad.getRowConstraints().add(constraints);
        }

        return keypad;
    }

    private void showHistoryExpression(CalculatorInput input, Label result, String expression) {
        input.setExpression(expression);
        result.setText("");
        result.pseudoClassStateChanged(ERROR_STATE, false);
    }

    public static void main(String[] args) {
        launch(args);
    }
}
