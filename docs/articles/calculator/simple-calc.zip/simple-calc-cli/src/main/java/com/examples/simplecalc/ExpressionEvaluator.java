package com.examples.simplecalc;

import java.math.BigDecimal;
import java.math.MathContext;
import java.util.Objects;

public final class ExpressionEvaluator {

    private static final MathContext DIVISION_CONTEXT = MathContext.DECIMAL128;

    public BigDecimal evaluate(String expression) {
        return new Parser(Objects.requireNonNull(expression, "expression")).parse();
    }

    private static final class Parser {

        private final String expression;
        private int position;

        private Parser(String expression) {
            this.expression = expression;
        }

        private BigDecimal parse() {
            skipWhitespace();
            if (isAtEnd()) {
                throw invalidExpression();
            }

            BigDecimal result = parseExpression();
            skipWhitespace();
            if (!isAtEnd()) {
                throw invalidExpression();
            }
            return result;
        }

        private BigDecimal parseExpression() {
            BigDecimal result = parseTerm();
            while (true) {
                skipWhitespace();
                if (match('+')) {
                    result = result.add(parseTerm());
                } else if (match('-')) {
                    result = result.subtract(parseTerm());
                } else {
                    return result;
                }
            }
        }

        private BigDecimal parseTerm() {
            BigDecimal result = parseUnary();
            while (true) {
                skipWhitespace();
                if (match('*')) {
                    result = result.multiply(parseUnary());
                } else if (match('/')) {
                    BigDecimal divisor = parseUnary();
                    if (divisor.signum() == 0) {
                        throw new ArithmeticException("Division by zero");
                    }
                    result = result.divide(divisor, DIVISION_CONTEXT);
                } else {
                    return result;
                }
            }
        }

        private BigDecimal parseUnary() {
            skipWhitespace();
            if (match('+')) {
                return parseUnary();
            }
            if (match('-')) {
                return parseUnary().negate();
            }
            return parsePrimary();
        }

        private BigDecimal parsePrimary() {
            skipWhitespace();
            if (match('(')) {
                BigDecimal result = parseExpression();
                skipWhitespace();
                if (!match(')')) {
                    throw invalidExpression();
                }
                return result;
            }
            return parseNumber();
        }

        private BigDecimal parseNumber() {
            skipWhitespace();
            int start = position;
            boolean hasDigits = consumeDigits();
            if (match('.')) {
                boolean hasFractionalDigits = consumeDigits();
                if (!hasDigits && !hasFractionalDigits) {
                    throw invalidExpression();
                }
            } else if (!hasDigits) {
                throw invalidExpression();
            }

            String number = expression.substring(start, position);
            if (number.startsWith(".")) {
                number = "0" + number;
            }
            try {
                return new BigDecimal(number);
            } catch (NumberFormatException exception) {
                throw invalidExpression();
            }
        }

        private boolean consumeDigits() {
            int start = position;
            while (!isAtEnd() && expression.charAt(position) >= '0' && expression.charAt(position) <= '9') {
                position++;
            }
            return position > start;
        }

        private boolean match(char expected) {
            if (!isAtEnd() && expression.charAt(position) == expected) {
                position++;
                return true;
            }
            return false;
        }

        private void skipWhitespace() {
            while (!isAtEnd() && Character.isWhitespace(expression.charAt(position))) {
                position++;
            }
        }

        private boolean isAtEnd() {
            return position >= expression.length();
        }

        private IllegalArgumentException invalidExpression() {
            return new IllegalArgumentException("Invalid expression");
        }
    }
}
