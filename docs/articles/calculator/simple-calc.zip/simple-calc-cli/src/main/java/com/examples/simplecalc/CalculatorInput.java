package com.examples.simplecalc;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;

public final class CalculatorInput {

    private final StringProperty expression = new SimpleStringProperty(this, "expression", "");

    public String getExpression() {
        return expression.get();
    }

    public StringProperty expressionProperty() {
        return expression;
    }

    public void setExpression(String value) {
        expression.set(value);
    }

    public void append(String key) {
        expression.set(getExpression() + key);
    }
}
