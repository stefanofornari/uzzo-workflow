package com.examples.simplecalc;

public final class CalculationDisplay {

    private final ExpressionEvaluator evaluator = new ExpressionEvaluator();

    public Display evaluate(String expression) {
        try {
            String text = evaluator.evaluate(expression).stripTrailingZeros().toPlainString();
            return new Display(text, false);
        } catch (ArithmeticException | IllegalArgumentException exception) {
            return new Display("Error", true);
        }
    }

    public record Display(String text, boolean isError) {
    }
}
